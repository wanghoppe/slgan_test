"""The tensorlayer.cli module provides a command-line tool for some common tasks."""
